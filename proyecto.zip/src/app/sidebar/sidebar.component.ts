import { PedidoService } from './../pedido.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  constructor(private PedidoService: PedidoService) { }
  public listdeVideos:Array<any> =[]

  ngOnInit(): void {
    this.PedidoService.disparadorDeFavoritos.subscribe((data: any) => {
      console.log('Recibiendo data...',data);
      this.listdeVideos.push(data);
      
    })
  }

}
